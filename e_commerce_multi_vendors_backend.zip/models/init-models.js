var DataTypes = require("sequelize").DataTypes;
var _categories = require("./categories");
var _news = require("./news");
var _order_details = require("./order_details");
var _orders = require("./orders");
var _permissions = require("./permissions");
var _product_images = require("./product_images");
var _products = require("./products");
var _products_latest = require("./products_latest");
var _role_permissions = require("./role_permissions");
var _roles = require("./roles");
var _user_phones = require("./user_phones");
var _user_product_target = require("./user_product_target");
var _user_roles = require("./user_roles");
var _user_targets = require("./user_targets");
var _users = require("./users");

function initModels(sequelize) {
  var categories = _categories(sequelize, DataTypes);
  var news = _news(sequelize, DataTypes);
  var order_details = _order_details(sequelize, DataTypes);
  var orders = _orders(sequelize, DataTypes);
  var permissions = _permissions(sequelize, DataTypes);
  var product_images = _product_images(sequelize, DataTypes);
  var products = _products(sequelize, DataTypes);
  var products_latest = _products_latest(sequelize, DataTypes);
  var role_permissions = _role_permissions(sequelize, DataTypes);
  var roles = _roles(sequelize, DataTypes);
  var user_phones = _user_phones(sequelize, DataTypes);
  var user_product_target = _user_product_target(sequelize, DataTypes);
  var user_roles = _user_roles(sequelize, DataTypes);
  var user_targets = _user_targets(sequelize, DataTypes);
  var users = _users(sequelize, DataTypes);

  products.belongsTo(categories, { as: "category", foreignKey: "category_id"});
  categories.hasMany(products, { as: "products", foreignKey: "category_id"});
  order_details.belongsTo(orders, { as: "order", foreignKey: "order_id"});
  orders.hasMany(order_details, { as: "order_details", foreignKey: "order_id"});
  role_permissions.belongsTo(permissions, { as: "permission", foreignKey: "permission_id"});
  permissions.hasMany(role_permissions, { as: "role_permissions", foreignKey: "permission_id"});
  order_details.belongsTo(products, { as: "product", foreignKey: "product_id"});
  products.hasMany(order_details, { as: "order_details", foreignKey: "product_id"});
  product_images.belongsTo(products, { as: "product", foreignKey: "product_id"});
  products.hasMany(product_images, { as: "product_images", foreignKey: "product_id"});
  user_product_target.belongsTo(products, { as: "product", foreignKey: "product_id"});
  products.hasMany(user_product_target, { as: "user_product_targets", foreignKey: "product_id"});
  order_details.belongsTo(products_latest, { as: "latest_product", foreignKey: "latest_product_id"});
  products_latest.hasMany(order_details, { as: "order_details", foreignKey: "latest_product_id"});
  role_permissions.belongsTo(roles, { as: "role", foreignKey: "role_id"});
  roles.hasMany(role_permissions, { as: "role_permissions", foreignKey: "role_id"});
  user_roles.belongsTo(roles, { as: "role", foreignKey: "role_id"});
  roles.hasMany(user_roles, { as: "user_roles", foreignKey: "role_id"});
  orders.belongsTo(users, { as: "user", foreignKey: "user_id"});
  users.hasMany(orders, { as: "orders", foreignKey: "user_id"});
  user_phones.belongsTo(users, { as: "user", foreignKey: "user_id"});
  users.hasMany(user_phones, { as: "user_phones", foreignKey: "user_id"});
  user_product_target.belongsTo(users, { as: "user", foreignKey: "user_id"});
  users.hasMany(user_product_target, { as: "user_product_targets", foreignKey: "user_id"});
  user_roles.belongsTo(users, { as: "user", foreignKey: "user_id"});
  users.hasMany(user_roles, { as: "user_roles", foreignKey: "user_id"});
  user_targets.belongsTo(users, { as: "user", foreignKey: "user_id"});
  users.hasMany(user_targets, { as: "user_targets", foreignKey: "user_id"});

  return {
    categories,
    news,
    order_details,
    orders,
    permissions,
    product_images,
    products,
    products_latest,
    role_permissions,
    roles,
    user_phones,
    user_product_target,
    user_roles,
    user_targets,
    users,
  };
}
module.exports = initModels;
module.exports.initModels = initModels;
module.exports.default = initModels;
