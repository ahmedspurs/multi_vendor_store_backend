let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();
chai.use(chaiHttp)


describe('/can  create  news', () => {
  it('it should create  new  news ', (done) => {
    chai.request(server)
      .post('/api/news')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get all  news  data', () => {
  it('it should GET all the news', (done) => {
    chai.request(server)
      .get('/api/news')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get news by id', () => {
  it('it should GET all the news', (done) => {
    chai.request(server)
      .get('/api/news/1')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can  update news', () => {
  it('it should update news with the id ', (done) => {
    chai.request(server)
      .put('/api/news/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  get   news with paginate', () => {
  it('it should get  news with paginate ', (done) => {
    chai.request(server)
      .post('/api/news/paginate')
      .send({limit: 20,page:1})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  delete  news', () => {
  it('it should delete    news ', (done) => {
    chai.request(server)
      .delete('/api/news/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});


