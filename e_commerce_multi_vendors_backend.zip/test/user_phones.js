let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();
chai.use(chaiHttp)


describe('/can  create  user_phones', () => {
  it('it should create  new  user_phones ', (done) => {
    chai.request(server)
      .post('/api/user-phones')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get all  user_phones  data', () => {
  it('it should GET all the user_phones', (done) => {
    chai.request(server)
      .get('/api/user-phones')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get user_phones by id', () => {
  it('it should GET all the user_phones', (done) => {
    chai.request(server)
      .get('/api/user-phones/1')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can  update user_phones', () => {
  it('it should update user_phones with the id ', (done) => {
    chai.request(server)
      .put('/api/user-phones/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  get   user_phones with paginate', () => {
  it('it should get  user_phones with paginate ', (done) => {
    chai.request(server)
      .post('/api/user-phones/paginate')
      .send({limit: 20,page:1})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  delete  user_phones', () => {
  it('it should delete    user_phones ', (done) => {
    chai.request(server)
      .delete('/api/user-phones/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});


