let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();
chai.use(chaiHttp)


describe('/can  create  permissions', () => {
  it('it should create  new  permissions ', (done) => {
    chai.request(server)
      .post('/api/permissions')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get all  permissions  data', () => {
  it('it should GET all the permissions', (done) => {
    chai.request(server)
      .get('/api/permissions')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get permissions by id', () => {
  it('it should GET all the permissions', (done) => {
    chai.request(server)
      .get('/api/permissions/1')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can  update permissions', () => {
  it('it should update permissions with the id ', (done) => {
    chai.request(server)
      .put('/api/permissions/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  get   permissions with paginate', () => {
  it('it should get  permissions with paginate ', (done) => {
    chai.request(server)
      .post('/api/permissions/paginate')
      .send({limit: 20,page:1})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  delete  permissions', () => {
  it('it should delete    permissions ', (done) => {
    chai.request(server)
      .delete('/api/permissions/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});


