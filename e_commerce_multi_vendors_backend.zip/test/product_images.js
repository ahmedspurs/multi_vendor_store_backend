let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();
chai.use(chaiHttp)


describe('/can  create  product_images', () => {
  it('it should create  new  product_images ', (done) => {
    chai.request(server)
      .post('/api/product-images')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get all  product_images  data', () => {
  it('it should GET all the product_images', (done) => {
    chai.request(server)
      .get('/api/product-images')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get product_images by id', () => {
  it('it should GET all the product_images', (done) => {
    chai.request(server)
      .get('/api/product-images/1')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can  update product_images', () => {
  it('it should update product_images with the id ', (done) => {
    chai.request(server)
      .put('/api/product-images/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  get   product_images with paginate', () => {
  it('it should get  product_images with paginate ', (done) => {
    chai.request(server)
      .post('/api/product-images/paginate')
      .send({limit: 20,page:1})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  delete  product_images', () => {
  it('it should delete    product_images ', (done) => {
    chai.request(server)
      .delete('/api/product-images/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});


