let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();
chai.use(chaiHttp)


describe('/can  create  order_details', () => {
  it('it should create  new  order_details ', (done) => {
    chai.request(server)
      .post('/api/order-details')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get all  order_details  data', () => {
  it('it should GET all the order_details', (done) => {
    chai.request(server)
      .get('/api/order-details')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get order_details by id', () => {
  it('it should GET all the order_details', (done) => {
    chai.request(server)
      .get('/api/order-details/1')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can  update order_details', () => {
  it('it should update order_details with the id ', (done) => {
    chai.request(server)
      .put('/api/order-details/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  get   order_details with paginate', () => {
  it('it should get  order_details with paginate ', (done) => {
    chai.request(server)
      .post('/api/order-details/paginate')
      .send({limit: 20,page:1})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  delete  order_details', () => {
  it('it should delete    order_details ', (done) => {
    chai.request(server)
      .delete('/api/order-details/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});


