let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();
chai.use(chaiHttp)


describe('/can  create  user_product_target', () => {
  it('it should create  new  user_product_target ', (done) => {
    chai.request(server)
      .post('/api/user-product-target')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get all  user_product_target  data', () => {
  it('it should GET all the user_product_target', (done) => {
    chai.request(server)
      .get('/api/user-product-target')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get user_product_target by id', () => {
  it('it should GET all the user_product_target', (done) => {
    chai.request(server)
      .get('/api/user-product-target/1')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can  update user_product_target', () => {
  it('it should update user_product_target with the id ', (done) => {
    chai.request(server)
      .put('/api/user-product-target/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  get   user_product_target with paginate', () => {
  it('it should get  user_product_target with paginate ', (done) => {
    chai.request(server)
      .post('/api/user-product-target/paginate')
      .send({limit: 20,page:1})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  delete  user_product_target', () => {
  it('it should delete    user_product_target ', (done) => {
    chai.request(server)
      .delete('/api/user-product-target/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});


