let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();
chai.use(chaiHttp)


describe('/can  create  orders', () => {
  it('it should create  new  orders ', (done) => {
    chai.request(server)
      .post('/api/orders')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get all  orders  data', () => {
  it('it should GET all the orders', (done) => {
    chai.request(server)
      .get('/api/orders')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get orders by id', () => {
  it('it should GET all the orders', (done) => {
    chai.request(server)
      .get('/api/orders/1')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can  update orders', () => {
  it('it should update orders with the id ', (done) => {
    chai.request(server)
      .put('/api/orders/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  get   orders with paginate', () => {
  it('it should get  orders with paginate ', (done) => {
    chai.request(server)
      .post('/api/orders/paginate')
      .send({limit: 20,page:1})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  delete  orders', () => {
  it('it should delete    orders ', (done) => {
    chai.request(server)
      .delete('/api/orders/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});


