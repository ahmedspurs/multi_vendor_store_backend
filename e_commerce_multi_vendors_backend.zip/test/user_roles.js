let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();
chai.use(chaiHttp)


describe('/can  create  user_roles', () => {
  it('it should create  new  user_roles ', (done) => {
    chai.request(server)
      .post('/api/user-roles')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get all  user_roles  data', () => {
  it('it should GET all the user_roles', (done) => {
    chai.request(server)
      .get('/api/user-roles')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get user_roles by id', () => {
  it('it should GET all the user_roles', (done) => {
    chai.request(server)
      .get('/api/user-roles/1')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can  update user_roles', () => {
  it('it should update user_roles with the id ', (done) => {
    chai.request(server)
      .put('/api/user-roles/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  get   user_roles with paginate', () => {
  it('it should get  user_roles with paginate ', (done) => {
    chai.request(server)
      .post('/api/user-roles/paginate')
      .send({limit: 20,page:1})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  delete  user_roles', () => {
  it('it should delete    user_roles ', (done) => {
    chai.request(server)
      .delete('/api/user-roles/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});


