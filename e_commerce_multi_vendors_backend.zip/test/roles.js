let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');
let should = chai.should();
chai.use(chaiHttp)


describe('/can  create  roles', () => {
  it('it should create  new  roles ', (done) => {
    chai.request(server)
      .post('/api/roles')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get all  roles  data', () => {
  it('it should GET all the roles', (done) => {
    chai.request(server)
      .get('/api/roles')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can get roles by id', () => {
  it('it should GET all the roles', (done) => {
    chai.request(server)
      .get('/api/roles/1')
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});
describe('/can  update roles', () => {
  it('it should update roles with the id ', (done) => {
    chai.request(server)
      .put('/api/roles/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  get   roles with paginate', () => {
  it('it should get  roles with paginate ', (done) => {
    chai.request(server)
      .post('/api/roles/paginate')
      .send({limit: 20,page:1})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});

describe('/can  delete  roles', () => {
  it('it should delete    roles ', (done) => {
    chai.request(server)
      .delete('/api/roles/1')
      .send({name: "name"})
      .end((err, res) => {
        res.should.have.status(200);
        res.body.status.should.eql(true); done();
      });
  });
});


